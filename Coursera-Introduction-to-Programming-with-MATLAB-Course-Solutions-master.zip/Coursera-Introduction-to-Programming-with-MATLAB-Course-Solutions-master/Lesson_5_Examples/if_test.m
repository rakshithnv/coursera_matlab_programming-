function if_test(x) 
if x
    fprintf('%d is true!\n',x);
else
    fprintf('%d is false!\n',x);
end
