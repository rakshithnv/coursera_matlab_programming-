function guess_my_number(x)
if x == 2
	fprintf('Congrats! You guessed my number!\n');
end



