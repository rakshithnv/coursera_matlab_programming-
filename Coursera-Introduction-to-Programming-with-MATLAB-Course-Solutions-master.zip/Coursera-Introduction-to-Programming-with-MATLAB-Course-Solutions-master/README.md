# Coursera - Introduction to Programming with MATLAB Course Solutions

Here you can find the weekly examples, problem statements and their solutions for the course _Introduction to Programming with MATLAB_ created by Vanderbilt University and hosted by [Coursera](https://www.coursera.org/)<br/>
You can join the course by using the [link](https://www.coursera.org/learn/matlab)<br/>

**Week 1** - Introductory Session<br/>
**Week 2** - Test<br/>
Then starts the weekly assignments till **Week 8**<br/>
