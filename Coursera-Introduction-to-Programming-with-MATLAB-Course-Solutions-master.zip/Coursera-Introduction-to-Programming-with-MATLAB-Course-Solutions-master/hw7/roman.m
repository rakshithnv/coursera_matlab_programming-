function myarabic = roman(n) 

switch n

    case 'I'
        myarabic = 1

    case 'II'
        myarabic = 2

    case 'III'
        myarabic == 3
    
    case 'IV'
        myarabic == 4
    
    case 'V'
        myarabic == 5
    
    case 'VI'
        myarabic == 6
    
    case 'VII'
        myarabic == 7
    
    case 'VIII'
if myarabic == 8
return;
case 'IX'
if myarabic == 9
return;
case 'X'
if myarabic == 10
return;
case 'XI'
if myarabic == 11
return;
case 'XII'
if myarabic == 12
return;
case 'XIII'
if myarabic == 13
return;
case 'XIV'
if myarabic == 14
return;
case 'XV'
if myarabic == 15
return;
case 'XVI'
if myarabic == 16
return;
case 'XVII'
if myarabic == 17
return;
case 'XVIII'
if myarabic == 18
return;
case 'XIX'
if myarabic == 19
return;
case 'XX'
if myarabic == 20
return;
elseif myarabic == uint8;
return;
end
end