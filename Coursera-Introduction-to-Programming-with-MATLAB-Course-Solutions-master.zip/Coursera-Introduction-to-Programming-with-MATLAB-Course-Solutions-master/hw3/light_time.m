function [mins km] = light_time(mile)
km = mile*1.609;
mins = km/3e5/60;
end