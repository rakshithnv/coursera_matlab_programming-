function H = hulk(v)
H = [v' (v').^2 (v').^3];


function H = hulk(v)
 
    H = [v' (v').^2 (v').^3];
end

%Here we need to remember to transpose the vector to get the required arrangement.
