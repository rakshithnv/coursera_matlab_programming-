function v = int_col(n)
v = [n 1:n-1]';
end