function out = odd_index(M)
out = M(1:2:end, 1:2:end);
end