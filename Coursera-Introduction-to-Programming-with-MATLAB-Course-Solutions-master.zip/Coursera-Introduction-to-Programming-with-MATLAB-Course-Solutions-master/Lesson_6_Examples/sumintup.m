function sumintup(N)
total = 0;
for n = 1:N
    total = total + n;
end
fprintf('total equals %d\n',total);
