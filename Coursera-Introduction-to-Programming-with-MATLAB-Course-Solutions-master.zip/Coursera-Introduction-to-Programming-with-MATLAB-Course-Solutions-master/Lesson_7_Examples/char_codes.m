function char_codes
for ii = 33:126
    fprintf('%s',ii);
end
fprintf('%s',10);
